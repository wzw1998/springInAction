package com;

public class getCurrentPath {

    public static void main(String[] args) {
        System.out.println(System.getProperty("user.dir"));
    }
}
